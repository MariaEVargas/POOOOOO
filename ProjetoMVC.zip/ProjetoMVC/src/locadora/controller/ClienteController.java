/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package locadora.controller;

/**
 *
 * @author medua
 */
public class ClienteController {
    
    public boolean cadastrarCliente(int codCliente, String nome, String cpf, String email, String endereco){
        
        if(nome != null && nome.length()>0 && validarCPF(cpf) && email != null && email.length()>0 && endereco != null && endereco.length()>0){
            Cliente cliente = new Cliente(codCliente, nome, cpf, email, endereco)
            cliente.cadastrarCliente(cliente);
            return true;
        }
    return false;
    }
    
    public boolean validarCPF(String cpf){
        for(int=0; i<cpf.length(); i++){
            if(!Character.isDigit(cpf.charAt(i))){
                if(!( i=3 || i==7 || 11)){
                    return false;
                }
            }
        }
        return true;
    }
}
