/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package locadora.controller;

/**
 *
 * @author rober
 */
public class AutomovelController {
    public boolean cadastrarAutomovel(String nome, String marca, String modelo, String placa,
        String cor, int nro_portas, int tipo_combustivel, long quilometragem, long renavam,
        String chassi, double valor_locacao){
        if(nome != null && nome.length() >0 && marca != null && marca.length() >0 && )
      
    }
}