
package locadora.model;

import java.util.ArrayList;

public class Automovel {
private int codAutomovel;
private String placa;
private String cor;
private int nro_portas;
private int tipo_combustivel;
private long quilometragem;
private long renavam;
private String chassi;
private double valor_locacao;
private ArrayList<Item> itens = new ArrayList<>();



}
