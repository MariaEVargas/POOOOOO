
package locadora.model;

public class Marca {
    
}
