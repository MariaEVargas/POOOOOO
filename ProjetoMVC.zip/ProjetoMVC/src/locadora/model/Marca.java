
package locadora.model;

public class Marca extends Modelo{
    
}
