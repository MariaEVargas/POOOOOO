
package locadora.model;


public class Modelo {
    
}
