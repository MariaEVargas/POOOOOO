
package locadora.model;


public class Modelo extends Automovel{
    
}
