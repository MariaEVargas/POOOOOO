/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package locadora.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import locadora.model.Cliente;

/**
 *
 * @author medua
 */
public class ClienteDAO {
    public void cadastrarCliente(Cliente cliente) throws ExceptionDAO{
        
    }
    public void removerCliente(Cliente cliente) throws ExceptionDAO{
        
    }
       
}

