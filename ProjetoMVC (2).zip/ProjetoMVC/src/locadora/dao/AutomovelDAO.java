/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package locadora.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import locadora.model.Automovel;
import locadora.dao.ConnectionMVC;
/**
 *
 * @author rober
 */
public class AutomovelDAO {
    public void cadastrarAutomovel(Automovel automovel) throws ExceptionDAO {
        String sql = "insert into automovel (placa, cor, nro_portas, tipo_combustivel, quilometragem,renavam, chassi, valor_locacao) value (?,?,?,?,?,?,?,?)";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
        try {
            connection = new ConnectionMVC().getConnection();
            pStatement = connection.prepareStatement(sql);
            pStatement.setString(1, automovel.getPlaca());
            pStatement.setString(2, automovel.getCor());
            pStatement.setInt(3, automovel.getNro_portas());
            pStatement.setInt(4, automovel.getTipo_combustivel());
            pStatement.setLong(5, automovel.getQuilometragem());
            pStatement.setLong(6, automovel.getRenavam());
            pStatement.setString(7, automovel.getChassi());
            pStatement.setDouble(8, automovel.getValor_locacao());
            
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao cadastrar automóvel: " + e);
        } finally {
           try {
            if (pStatement != null){pStatement.close();}
        } catch (SQLException e){
            throw new ExceptionDAO("Erro ao fechar o Statement: " + e);
        } try {
            if (connection != null) {connection.close();}
        } catch (SQLException e){
            throw new ExceptionDAO ("Erro ao fechar a conexão" + e);
        }
     }
   }
    
    public void buscarAutomovel(Automovel automovel){
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        
        String sql = "SELECT + FROM automovel WHERE codAutomovel=?";
        
        try {
            ps = conn.prepareStatement(sql);
            ps.setInt(1, pro.getCodAutomovel);
            rs = ps.executeQuery();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println(e);
            }
        }
    }
}
